<?php
// contact.php - Contact form submission handler

$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = $_POST['name'] ?? '';
  $email = $_POST['email'] ?? '';
  $message = $_POST['message'] ?? '';

  if ($name && $email && $message) {
    // For real usage, configure mail() or store messages in DB
    // mail('your@email.com', "New Contact Message", $message);
    $success = "Thank you, $name. Your message has been received!";
  } else {
    $error = "Please fill in all fields.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - Hope Bridge</title>
  <link rel="stylesheet" href="css/style.css"> <!-- ✅ CSS -->
  <script src="js/script.js" defer></script>    <!-- ✅ JavaScript -->
</head>
<body>

  <?php include 'includes/header.php'; ?> <!-- ✅ Header include -->

  <main>
    <section class="contact-form">
      <h2>Contact Us</h2>
      <p>If you have any questions or want to get involved, please reach out!</p>

      <?php if ($success): ?>
        <p class="success"><?php echo $success; ?></p>
      <?php elseif ($error): ?>
        <p class="error"><?php echo $error; ?></p>
      <?php endif; ?>

      <form method="POST" action="contact.php">
        <label for="name">Name*</label><br>
        <input type="text" name="name" id="name" required><br><br>

        <label for="email">Email*</label><br>
        <input type="email" name="email" id="email" required><br><br>

        <label for="message">Message*</label><br>
        <textarea name="message" id="message" rows="5" required></textarea><br><br>

        <button type="submit">Send Message</button>
      </form>
    </section>
  </main>

  <?php include 'includes/footer.php'; ?> <!-- ✅ Footer include -->

</body>
</html>
