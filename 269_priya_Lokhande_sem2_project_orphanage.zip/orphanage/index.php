<?php
// index.php - Home page of Hope Bridge
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hope Bridge - Home</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/style.css"> <!-- ✅ CSS -->
  <script src="js/script.js" defer></script>    <!-- ✅ JavaScript -->
</head>
<body>

  <?php include 'includes/header.php'; ?> <!-- ✅ Header include -->

  <main>
    <section class="hero">
      <h2>Your kindness builds futures</h2>
      <p>Hope Bridge connects generous hearts with orphanages in need.</p>
      <img src="images/orphan.avif" alt="Orphanage Banner" style="max-width: 100%; height: auto;">
      <br><br>
      <a href="donate.php">
        <button class="donate-btn">Donate Now</button>
      </a>
    </section>
  </main>

  <?php include 'includes/footer.php'; ?> <!-- ✅ Footer include -->

</body>
</html>
