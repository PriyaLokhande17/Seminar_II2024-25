<header>
  <h1>Hope Bridge</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="donate.php">Donate</a>
    <a href="orphanages.php">Orphanages</a>
    <a href="contact.php">Contact</a>
  </nav>
</header>
