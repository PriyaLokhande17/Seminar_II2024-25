<footer>
  <p>&copy; <?php echo date("Y"); ?> Hope Bridge. All rights reserved.</p>
</footer>
