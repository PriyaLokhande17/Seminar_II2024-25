<?php
session_start();
include 'php/connect.php';

// Check if user's email is stored in session
$email = $_SESSION['user_email'] ?? '';

if (!$email) {
    echo "<p>No donation record found. Please make a donation first.</p>";
    exit;
}

// Fetch user's donations
$stmt = $conn->prepare("SELECT name, amount, donated_at FROM donations WHERE email = ? ORDER BY donated_at DESC");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Donations - Hope Bridge</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main>
  <section class="donation-history">
    <h2>My Donation History</h2>

    <?php if ($result->num_rows > 0): ?>
      <table border="1" cellpadding="8" cellspacing="0">
        <tr>
          <th>Name</th>
          <th>Amount (₹)</th>
          <th>Date</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['amount']); ?></td>
            <td><?php echo htmlspecialchars($row['donated_at']); ?></td>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p>You haven’t made any donations yet.</p>
    <?php endif; ?>
  </section>
</main>

<?php include 'includes/footer.php'; ?>

</body>
</html>
