<?php
include 'php/connect.php';
$result = $conn->query("SELECT * FROM orphanages");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Orphanages</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

  <h2>Our Partner Orphanages</h2>
  <ul>
    <?php while($row = $result->fetch_assoc()): ?>
      <li>
        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
        <p><?php echo htmlspecialchars($row['description']); ?></p>
        <img src="images/<?php echo htmlspecialchars($row['image_url']); ?>" width="200" alt="<?php echo htmlspecialchars($row['name']); ?>">
      </li>
    <?php endwhile; ?>
  </ul>

  <hr>

  <h2>Other Notable Organizations</h2>
  <p>Explore more NGOs working across education, child care, and social development:</p>
  <ul>
    <li>
      <strong>Smile Foundation</strong><br>
      Focus: Education, Healthcare, Women Empowerment<br>
      Website: <a href="https://www.smilefoundationindia.org/" target="_blank">smilefoundationindia.org</a>
    </li>
    <li>
      <strong>CRY – Child Rights and You</strong><br>
      Focus: Child Rights, Nutrition, Education<br>
      Website: <a href="https://www.cry.org/" target="_blank">cry.org</a>
    </li>
    <li>
      <strong>SOS Children’s Villages</strong><br>
      Focus: Family homes for orphans<br>
      Website: <a href="https://www.soschildrensvillages.in/" target="_blank">soschildrensvillages.in</a>
    </li>
    <li>
      <strong>Deepalaya</strong><br>
      Focus: Underprivileged Child Education<br>
      Website: <a href="https://www.deepalaya.org/" target="_blank">deepalaya.org</a>
    </li>
  </ul>

<?php include 'includes/footer.php'; ?>

</body>
</html>
