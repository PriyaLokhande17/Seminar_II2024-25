<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM orphanages WHERE id = $id");
    $row = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $image = $_POST['image_url'];
    $stmt = $conn->prepare("UPDATE orphanages SET name=?, description=?, image_url=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $desc, $image, $id);
    $stmt->execute();
    echo "Orphanage updated!";
    exit();
}
?>
<form method="post">
  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
  Name: <input type="text" name="name" value="<?php echo $row['name']; ?>"><br>
  Description: <textarea name="description"><?php echo $row['description']; ?></textarea><br>
  Image URL: <input type="text" name="image_url" value="<?php echo $row['image_url']; ?>"><br>
  <input type="submit" value="Update">
</form>