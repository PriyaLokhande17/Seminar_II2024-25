<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $image = $_POST['image_url'];
    $stmt = $conn->prepare("INSERT INTO orphanages (name, description, image_url) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $desc, $image);
    $stmt->execute();
    echo "Orphanage added!";
}
?><form method="post">
  Name: <input type="text" name="name"><br>
  Description: <textarea name="description"></textarea><br>
  Image URL: <input type="text" name="image_url"><br>
  <input type="submit" value="Add">
</form>