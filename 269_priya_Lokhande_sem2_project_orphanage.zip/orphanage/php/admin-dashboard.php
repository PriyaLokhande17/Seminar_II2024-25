
<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';
$total = $conn->query("SELECT COUNT(*) AS count FROM donations")->fetch_assoc();
$orphans = $conn->query("SELECT COUNT(*) AS count FROM orphanages")->fetch_assoc();
?>

<h2>Admin Dashboard</h2>
<p>Total Donations: <?php echo $total['count']; ?></p>
<p>Total Orphanages: <?php echo $orphans['count']; ?></p>
<a href="add-orphanage.php">Add Orphanage</a><br>
<a href="view-donations.php">View Donations</a><br>
<a href="logout.php">Logout</a>