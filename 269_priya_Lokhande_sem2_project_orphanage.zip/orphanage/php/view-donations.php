<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';
$result = $conn->query("SELECT * FROM donations ORDER BY donated_at DESC");
?>
<h2>Donations</h2>
<table border="1">
<tr><th>Name</th><th>Email</th><th>Amount</th><th>Date</th></tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
  <td><?php echo $row['name']; ?></td>
  <td><?php echo $row['email']; ?></td>
  <td><?php echo $row['amount']; ?></td>
  <td><?php echo $row['donated_at']; ?></td>
</tr>
<?php endwhile; ?>
</table>