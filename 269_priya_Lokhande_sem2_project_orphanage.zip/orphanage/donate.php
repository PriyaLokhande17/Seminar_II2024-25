<?php
session_start(); // ✅ Start session at top
include 'php/connect.php'; // ✅ Database connection

$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = $_POST['name'] ?? '';
  $email = $_POST['email'] ?? '';
  $amount = $_POST['amount'] ?? '';

  if ($name && $amount && is_numeric($amount)) {
    $stmt = $conn->prepare("INSERT INTO donations (name, email, amount) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $name, $email, $amount);
    
    if ($stmt->execute()) {
      // ✅ Store user email in session for later use
      if (!empty($email)) {
        $_SESSION['user_email'] = $email;
      }

      $success = "Thank you, $name! Your donation of ₹$amount was successful. <a href='my-donations.php'>View My Donations</a>";
    } else {
      $error = "Something went wrong. Please try again.";
    }
  } else {
    $error = "Please fill all required fields correctly.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Donate - Hope Bridge</title>
  <link rel="stylesheet" href="css/style.css"> <!-- ✅ CSS -->
  <script src="js/script.js" defer></script>    <!-- ✅ JavaScript -->
</head>
<body>

  <?php include 'includes/header.php'; ?> <!-- ✅ Header include -->

  <main>
    <section class="donation-form">
      <h2>Make a Donation</h2>
      <p>Your support helps provide food, shelter, and education for children in need.</p>

      <?php if ($success): ?>
        <p class="success"><?php echo $success; ?></p>
      <?php elseif ($error): ?>
        <p class="error"><?php echo $error; ?></p>
      <?php endif; ?>

      <form method="POST" action="donate.php">
        <label for="name">Full Name*</label><br>
        <input type="text" name="name" id="name" required><br><br>

        <label for="email">Email (optional)</label><br>
        <input type="email" name="email" id="email"><br><br>

        <label for="amount">Donation Amount (₹)*</label><br>
        <input type="number" name="amount" id="amount" required min="1" step="any"><br><br>

        <button type="submit">Donate Now</button>
      </form>
    </section>
  </main>

  <?php include 'includes/footer.php'; ?> <!-- ✅ Footer include -->

</body>
</html>
