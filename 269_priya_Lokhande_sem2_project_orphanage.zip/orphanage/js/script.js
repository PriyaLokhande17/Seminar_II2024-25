// script.js

document.addEventListener("DOMContentLoaded", () => {
  const donateBtn = document.querySelector(".donate-btn");
  if (donateBtn) {
    donateBtn.addEventListener("click", () => {
      alert("Thank you for supporting Hope Bridge!");
    });
  }
});
