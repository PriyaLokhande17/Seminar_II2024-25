<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us - Hope Bridge</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/style.css"> <!-- ✅ CSS linked -->
  <script src="js/script.js" defer></script>    <!-- ✅ JS linked -->
</head>
<body>

  <?php include 'includes/header.php'; ?> <!-- ✅ Header include -->

  <main>
    <section class="about-section">
      <h2>About Hope Bridge</h2>
      <p>
        Hope Bridge is a non-profit platform dedicated to supporting orphanages across the country. 
        Our mission is to connect generous donors with the children who need them the most.
      </p>

      <p>
        We work with verified orphanages to ensure transparency, trust, and impact. Every donation—big or small—helps provide shelter, education, nutrition, and emotional support to children in need.
      </p>

      <img src="images/orphan.avif" alt="Children in Hope Bridge care" style="width: 100%; max-width: 600px; border-radius: 12px; margin-top: 20px;">

      <h3>Why Choose Hope Bridge?</h3>
      <ul>
        <li>100% transparent donation process</li>
        <li>Direct impact on orphanages and children</li>
        <li>Real-time updates on fund utilization</li>
        <li>Secure and easy-to-use platform</li>
      </ul>
    </section>
  </main>

  <?php include 'includes/footer.php'; ?> <!-- ✅ Footer include -->

</body>
</html>
